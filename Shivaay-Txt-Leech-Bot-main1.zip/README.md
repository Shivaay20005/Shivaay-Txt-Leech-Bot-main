<p align="center">
  <img src="https://files.catbox.moe/5csii6.jpg" alt="SHIVAAY-TXT-LEECH-BOT Logo">
</p>
<h1 align="center">
  SHIVAAY TXT LEECH BOT
</h1>

## Deploy Tutorial - [By Shivaay King )
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Shivaay20005/Shivaay-Txt-Leech-Bot-main)


## Credit

<b><details><summary>Tap On Me For See Credit</summary>

💝 Credit Goes To [SHIVAAY](https://telegram.me/Shivaay20005) So Don't Forgot To Give Credit

💖 And Thank You So Much To All Who Help In This Journey 💕

Copyright ©️ [Shivaay](https://telegram.me/Shivaay20005)

</b>
</details>

## About Owner 
 [Shivaay](https://telegram.me/Shivaay20005)

</details>


### Copyright ©️ [SHIVAAY]()

<b>Selling This Repo Or Code Of This Repo For Money Is Strictly Prohibited By Shivaay 🚫</b>

