from os import environ

API_ID = int(environ.get("API_ID", "29473197"))
API_HASH = environ.get("API_HASH", "182c589126cae7e6128a63a5c0fd40d8")
BOT_TOKEN = environ.get("BOT_TOKEN", "7843459688:AAGCeQjdFqWGFrucHPRuV4XD-Uuj60WGoBU")
